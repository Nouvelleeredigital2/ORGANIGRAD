# @apps2026/contracts

Vocabulaire **partagé** de l'écosystème APPS-2026 : enveloppe d'événements Synapse,
catalogue d'événements canoniques, objets partagés (apps, validations,
notifications) et **validation runtime** (Zod). C'est la **source de vérité unique**
du contrat inter-applications.

> 📖 **Conformité d'émission** (registre `APP_EMIT_REGISTRY`, garde hub
> `enforce`/`warn`/`off`, self-test par app) : voir
> [`docs/registry-conformance.md`](./docs/registry-conformance.md).

> Contenu extrait à l'identique de `NED-IA-SYNAPS/apps/ned-ia-synapse/shared/types.ts`.
> Périmètre **v1 (strict)** : events + enveloppe + `ConnectedApp` + `ValidationRequest`
> + `NotificationRequest`. Les types Studio Graph / NodalWorkflow / WorkflowRoute
> seront ajoutés en v1.x au besoin (ajout = `minor`, rétro-compatible).

## Installation (distribution par tarball)

Le package n'est pas publié sur un registre. On le distribue par **tarball** :

```bash
# dans apps2026-contracts/
npm install
npm run pack:tgz        # build + npm pack → @apps2026-contracts-1.0.0.tgz
```

Puis dans chaque app consommatrice (TS/JS) :

```bash
npm install ../apps2026-contracts/apps2026-contracts-1.0.0.tgz
# package.json → "@apps2026/contracts": "file:../apps2026-contracts/apps2026-contracts-1.0.0.tgz"
```

## Usage (TypeScript)

```ts
import {
  createEvent,
  parseEvent,
  assertHermesNoControl,
  SYNAPSE_EVENT_ENVELOPE_VERSION,
  type SynapseEvent,
  type ConnectedApp,
} from "@apps2026/contracts";

// Émettre : fabrique une enveloppe conforme (version, status, createdAt, id auto)
const evt = createEvent({
  type: "validation.requested",
  sourceApp: "link",
  correlationId: cor,
  payload: { validationId, title },
});

// Recevoir : valide AU POINT D'ENTRÉE du bus (lève si non conforme)
const safe = parseEvent(rawBody);

// Garde B7 : Hermes ne peut pas porter de capability de contrôle
assertHermesNoControl(app);
```

## Apps non-TypeScript (Python / FastAPI)

Utiliser `schema/synapse-event.schema.json` (JSON Schema 2020-12) pour valider
côté Python (ex. `jsonschema`), ou générer des modèles avec
`datamodel-code-generator`.

## Versioning

- **Enveloppe** : `SYNAPSE_EVENT_ENVELOPE_VERSION` (`"1.0"`). Tout changement cassant
  l'incrémente ; les consommateurs filtrent par version.
- **Package** : SemVer. Nouvel `SynapseEventType` = `minor`. Forme d'enveloppe
  modifiée = `major` + bump de la version d'enveloppe.

## Migration (ordre)

1. **Synapse** (source) : réexporter `shared/types.ts` depuis ce package (preuve de non-régression : build + 146 tests verts).
2. **Socialize-EA** (2ᵉ consommateur réel) : remplacer ses types d'événements locaux.
3. **LINK**, puis les autres apps au moment où elles émettent/consomment des événements.
