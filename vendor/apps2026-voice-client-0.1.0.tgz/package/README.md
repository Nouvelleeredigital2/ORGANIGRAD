# @apps2026/voice-client

SDK vocal partagé APPS-2026, extrait de LINK (chantier 4, 2026-08-09).

Contenu :

- `useVoiceCapture` — capture micro PCM (AudioWorklet + fallback ScriptProcessor),
  VAD injectable (`VoiceActivityDetector`), push-to-talk, mute/revoke.
- `useBargeIn` / `BargeInController` — une seule annulation par lecture active,
  interruption distante best-effort et bornée dans le temps.
- `createVoiceGatewayClient({ proxyBasePath })` — client des routes proxy
  `POST {proxyBasePath}/frames` et `POST {proxyBasePath}/interruption`
  (défaut : `/api/voice/gateway`, même origine). Best-effort, ne rejette jamais.
- `@apps2026/voice-client/server` — `forwardVoiceGateway(action, payload, env)` :
  helper serveur (fetch pur, sans framework) qui relaie vers
  `NED_VOICE_GATEWAY_URL/v1/voice/{action}` avec `NED_VOICE_GATEWAY_TOKEN` en
  Bearer. 503 si non configuré, 502 si injoignable.

Règle de sécurité : le token gateway ne va JAMAIS au navigateur — chaque app
consommatrice fournit SON proxy serveur et le client n'appelle que ce proxy.

Distribution : tarball (`npm run pack:tgz`) vendorisé chez les consommateurs,
comme `@apps2026/contracts`. Consommateurs actuels : LINK, ORGANIGRAD.
