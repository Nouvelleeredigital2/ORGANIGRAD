# @apps2026/contracts

Vocabulaire **partagé** de l'écosystème APPS-2026 : enveloppe d'événements Synapse,
catalogue d'événements canoniques, objets partagés (apps, validations,
notifications) et **validation runtime** (Zod). C'est la **source de vérité unique**
du contrat inter-applications.

La version `1.7.0` rend le runtime compatible zod 3 et zod 4 (pair `^3.23.0 || ^4.0.0`, voir KI-010), sans changer les artefacts. La version `1.6.0` consolide les contrats pilotes déjà consommés par Synapse
(scopes, délégations, circuits, manifestes d'adaptateur) et ajoute le contrat
commun du ticket d'ouverture de projet.

La préversion en préparation `2.0.0-zod4.2` exige **Zod `^4.6.7`** et construit
ses déclarations avec cette version. Les validateurs UUID deviennent plus stricts
qu'avec Zod 3 ; vérifier les identifiants du consommateur avant adoption.
Les entiers non sûrs sont également refusés. Le format d'enveloppe et les JSON
Schema Draft 7 restent inchangés. Le générateur Zod 3 est isolé hors du package
distribué. Les exports éditoriaux du pilote LINK `1.7.0-editorial.1` sont conservés
par une nouvelle migration explicitement dérivée de son JS compilé et de ses
déclarations, avec oracle figé et provenance vérifiable ; le TypeScript original
n'est pas présenté comme retrouvé. L'adoption LINK exige ses propres tests.
Procédure et limites : [dossier Zod 4](./docs/ZOD4-RELEASE-20261106.md).

> 📖 **Conformité d'émission** (registre `APP_EMIT_REGISTRY`, garde hub
> `enforce`/`warn`/`off`, self-test par app) : voir
> [`docs/registry-conformance.md`](./docs/registry-conformance.md).

> Contenu extrait à l'identique de `NED-IA-SYNAPS/apps/ned-ia-synapse/shared/types.ts`.
> Périmètre **v1 (strict)** : events + enveloppe + `ConnectedApp` + `ValidationRequest`
> + `NotificationRequest`. Les types Studio Graph / NodalWorkflow / WorkflowRoute
> seront ajoutés en v1.x au besoin (ajout = `minor`, rétro-compatible).

## Installation (distribution par tarball)

Le package n'est pas publié sur un registre. On le distribue par **tarball** :

```bash
# dans apps2026-contracts/
npm install
npm run pack:tgz        # build + npm pack → @apps2026-contracts-1.0.0.tgz
```

Puis dans chaque app consommatrice (TS/JS) :

```bash
npm install ../apps2026-contracts/apps2026-contracts-1.0.0.tgz
# package.json → "@apps2026/contracts": "file:../apps2026-contracts/apps2026-contracts-1.0.0.tgz"
```

## Usage (TypeScript)

```ts
import {
  createEvent,
  parseEvent,
  assertHermesNoControl,
  SYNAPSE_EVENT_ENVELOPE_VERSION,
  type SynapseEvent,
  type ConnectedApp,
} from "@apps2026/contracts";

// Émettre : fabrique une enveloppe conforme (version, status, createdAt, id auto)
const evt = createEvent({
  type: "validation.requested",
  sourceApp: "link",
  correlationId: cor,
  payload: { validationId, title },
});

// Recevoir : valide AU POINT D'ENTRÉE du bus (lève si non conforme)
const safe = parseEvent(rawBody);

// Garde B7 : Hermes ne peut pas porter de capability de contrôle
assertHermesNoControl(app);
```

### Ouverture d'un projet dans une application

`suiteLaunchClaimsSchema` décrit les claims signés du ticket court transmis à
`/synapse/launch`. Ils portent l'utilisateur, le workspace, le `ProjectRef`, le
rôle, l'application cible, la clé d'idempotence et, si elle existe déjà, la
référence native. Leur durée maximale est de 90 secondes.

Le schéma ne valide ni signature, ni horloge, ni usage unique. Le hub signe et
persiste l'émission ; l'application cible échange le code côté serveur, revérifie
ses droits natifs, puis confirme le résultat. Aucun secret ou jeton durable ne
doit entrer dans les claims.

## Apps non-TypeScript (Python / FastAPI)

Utiliser `schema/synapse-event.schema.json` (JSON Schema 2020-12) pour valider
côté Python (ex. `jsonschema`), ou générer des modèles avec
`datamodel-code-generator`.

## Versioning

- **Enveloppe** : `SYNAPSE_EVENT_ENVELOPE_VERSION` (`"1.0"`). Tout changement cassant
  l'incrémente ; les consommateurs filtrent par version.
- **Package** : SemVer. Nouvel `SynapseEventType` = `minor`. Forme d'enveloppe
  modifiée = `major` + bump de la version d'enveloppe.

## Migration (ordre)

1. **Synapse** (source) : réexporter `shared/types.ts` depuis ce package (preuve de non-régression : build + 146 tests verts).
2. **Socialize-EA** (2ᵉ consommateur réel) : remplacer ses types d'événements locaux.
3. **LINK**, puis les autres apps au moment où elles émettent/consomment des événements.
